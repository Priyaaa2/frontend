import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { DataviewComponent } from './dataview/dataview.component';
import { ExcelsheetComponent } from './excelsheet/excelsheet.component';
import { HomepageComponent } from './homepage/homepage.component';


const routes: Routes = [
  { path: '',  redirectTo: '/excelupload', pathMatch: 'full'},
  {path:"home",component:HomepageComponent },
  {path:"excelupload",component:ExcelsheetComponent },
  {path:"contact",component:DataviewComponent },
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { 

}
