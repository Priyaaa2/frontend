import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { ExcelsheetComponent } from './excelsheet/excelsheet.component';
import { ReplaceNullWithTextPipe } from './replace-null-with-text.pipe';
import { EmpsheetService } from 'src/app/empsheet.service';
import { HttpClientModule } from '@angular/common/http';
import { DataviewComponent } from './dataview/dataview.component';
import { HomepageComponent } from './homepage/homepage.component';

@NgModule({
  declarations: [
    AppComponent,
    ExcelsheetComponent,
    ReplaceNullWithTextPipe,
    DataviewComponent,
    HomepageComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule
  ],
  providers: [ReplaceNullWithTextPipe, EmpsheetService],
  bootstrap: [AppComponent]
})
export class AppModule { }
