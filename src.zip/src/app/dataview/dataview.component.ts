import { Component, OnInit } from '@angular/core';
import { EmpsheetService } from '../empsheet.service';

@Component({
  selector: 'app-dataview',
  templateUrl: './dataview.component.html',
  styleUrls: ['./dataview.component.css']
})
export class DataviewComponent implements OnInit {
   usersData:any;
  showTable:boolean=false;
  constructor(private serviceCall: EmpsheetService) { }

  ngOnInit(): void {
      this.serviceCall.getTableData().subscribe(
        res =>{
          this.usersData = res;       
           this.showTable= true;
         
           console.log(res); 
        }
      );
  }

}
